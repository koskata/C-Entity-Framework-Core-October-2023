﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-QNFSKLL\SQLEXPRESS;Database=Medicines;Integrated Security=True;Encrypt=False";
    }
}
