﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CarDealer.Models
{
    public class PartCar
    {
        [ForeignKey(nameof(PartId))]
        public int PartId { get; set; }
        public Part Part { get; set; } = null!;

        [ForeignKey(nameof(CarId))]
        public int CarId { get; set; }
        public Car Car { get; set; } = null!; 
    }
}
