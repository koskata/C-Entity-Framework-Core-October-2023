﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-QNFSKLL\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
