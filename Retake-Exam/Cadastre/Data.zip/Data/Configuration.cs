﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-QNFSKLL\SQLEXPRESS;Database=Cadastre;Integrated Security=True;Encrypt=False";
    }
}
