﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastre.Data.Enumerations
{
    public enum Region
    {
        SouthEast,
        SouthWest,
        NorthEast,
        NorthWest
    }
}
